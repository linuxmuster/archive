# Linuxmuster.net session plugin

Plugin to handle a school session, share files with students, manage permissions and internet access.
