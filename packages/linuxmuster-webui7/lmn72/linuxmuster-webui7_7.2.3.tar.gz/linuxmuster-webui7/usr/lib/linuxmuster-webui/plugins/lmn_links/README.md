# LMN7 Links Plugin

Create config file /etc/linuxmuster/webui/links/links_list.json

```
[
  {
    "title": "Test123",
    "icon": "",
    "link": "https://www.google.de",
    "description": "Ganz langer Text",
    "permissions": { "student" }
  },
  {
    "title": "Test123",
    "icon": "",
    "link": "https://www.google.de",
    "description": "Ganz langer Text",
    "permissions": { "student", "teachers" }
  },
]
```

Permission = sophomorixRole