# Crontab extra plugin

This plugin manages crontab files and make it easier to run a job only if the current day is not a holiday day.
