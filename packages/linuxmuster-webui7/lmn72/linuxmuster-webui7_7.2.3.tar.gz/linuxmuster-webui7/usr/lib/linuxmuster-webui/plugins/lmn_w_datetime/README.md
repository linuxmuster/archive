# Linuxmuster.net datetime plugin

DEPRECATED.
