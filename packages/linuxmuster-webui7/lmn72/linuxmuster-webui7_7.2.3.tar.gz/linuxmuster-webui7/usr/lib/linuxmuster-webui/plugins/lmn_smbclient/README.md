# Samba share plugin

Provide tools to manage files, directories, upload, ... in samba shares, and deliver some useful informations about it.
