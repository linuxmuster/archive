# Linuxmuster.net groupmembership plugin

Plugin to handle basic groups (class, project, printer) and members in the LDAP tree.
