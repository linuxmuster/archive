# Linuxmuster.net users plugin

Plugin for users management.
