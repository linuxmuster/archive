# Linuxmuster.net settings plugin

Plugin to manage school.conf config file from sophomorix.
