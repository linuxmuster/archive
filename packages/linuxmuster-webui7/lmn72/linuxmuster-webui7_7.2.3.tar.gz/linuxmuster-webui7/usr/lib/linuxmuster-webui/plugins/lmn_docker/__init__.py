import logging
from .main import ItemProvider
from .views import Handler

logging.info('docker.__init__.py: docker loaded')
