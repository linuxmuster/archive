# Linbo extra plugin

Plugin to get all linbo config informations and launch some linbo commands to the hosts.
