# Linuxmuster.net auth plugin

LDAP auth plugin and permissions management.
