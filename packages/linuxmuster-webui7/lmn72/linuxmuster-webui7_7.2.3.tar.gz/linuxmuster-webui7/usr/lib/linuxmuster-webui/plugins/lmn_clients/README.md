# Ajenti plugin 

This plugin allows to perform some custom configurations to manage the clients in linuxmuster.net network.
