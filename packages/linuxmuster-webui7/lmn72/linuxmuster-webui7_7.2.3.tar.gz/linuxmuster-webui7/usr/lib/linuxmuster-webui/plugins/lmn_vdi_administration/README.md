# Ajenti plugin template

This is the plugin template used by ajenti-dev-multitool
