# Samba DNS extra plugin

This plugin manages the samba DNS through samba-tool.
