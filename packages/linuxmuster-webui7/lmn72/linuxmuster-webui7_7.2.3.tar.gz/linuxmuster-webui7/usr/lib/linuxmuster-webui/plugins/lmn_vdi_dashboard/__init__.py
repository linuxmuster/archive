import logging
from .main import ItemProvider
from .views import Handler

logging.info('lmn_vdi_dashboard.__init__.py: lmn_vdi_dashboard loaded')
